package com.example.SpringBootMVCProjectWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcProjectWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcProjectWebAppApplication.class, args);
		System.out.println("SpringBoot MVC Project");
	}

}
